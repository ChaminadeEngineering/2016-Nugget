/*
 * SearchAndMove.cpp
 *
 *  Created on: Mar 3, 2016
 *      Author: eeuser
 */
#include "SearchAndMove.h"


SearchAndMove::SearchAndMove()
{
	// Use Requires() here to declare subsystem dependencies
	// eg. Requires(chassis);
	Requires(CommandBase::pivot);
}


void SearchAndMove::Initialize()
{

}

//Called repeatedly when this Command is scheduled to run

void SearchAndMove::Execute()
{
	//We are moving up here--Only Up
	if(CommandBase::oi->getLeftXBoxAxis() > KDeadZoneLimit)
	{
		//Recieve the *Current* encoder value
		CommandBase::pivot->GetEncoderValue() ;

		//DO NOT MOVE!! AT HIGHEST POINT.
		if(CommandBase::pivot->GetEncoderValue() >= KSetPoint4 || CommandBase::pivot->GetUpperLimitSwitch() == true)
		{
			CommandBase::pivot->StopPivot() ;
		}

		//At SetPoint3 we will be moving to SetPoint4
		else if(CommandBase::pivot->GetEncoderValue() >= KSetPoint3)
		{
			CommandBase::pivot->MovePivotUP(KSetPoint4) ;
		}

		//At SetPoint2 we will be moving to SetPoint3
		else if(CommandBase::pivot->GetEncoderValue() >= KSetPoint2)
		{
			CommandBase::pivot->MovePivotUP(KSetPoint3) ;
		}

		//At SetPoint1 we will be moving to SetPoint2
		else if(CommandBase::pivot->GetEncoderValue() >= KSetPoint1)
		{
			CommandBase::pivot->MovePivotUP(KSetPoint2) ;
		}

		//At SetPoint0 we will be moving to SetPoint1
		else if(CommandBase::pivot->GetEncoderValue() >= KSetPoint0 || CommandBase::pivot->GetLowerLimitSwitch() == true)		{
			CommandBase::pivot->MovePivotUP(KSetPoint1) ;
		}

	}

	//We are moving down here--Only down
	else if(CommandBase::oi->getLeftXBoxAxis() < -KDeadZoneLimit)
	{
		//Recieve the *Current* encoder value
		CommandBase::pivot->GetEncoderValue() ;

		//DO NOT MOVE!!! AT LOWEST POINT.
		if(CommandBase::pivot->GetEncoderValue() <= KSetPoint0 || CommandBase::pivot->GetLowerLimitSwitch())
		{
			CommandBase::pivot->StopPivot() ;
		}

		//At SetPoint1 we go to SetPoint0
		else if(CommandBase::pivot->GetEncoderValue() <= KSetPoint1)
		{
			CommandBase::pivot->MovePivotDOWN(KSetPoint0) ;
		}

		//At SetPoint2 we go to SetPoint1
		else if(CommandBase::pivot->GetEncoderValue() <= KSetPoint2)
		{
			CommandBase::pivot->MovePivotDOWN(KSetPoint1) ;
		}

		//At SetPoint3 we move down to SetPoint2
		else if(CommandBase::pivot->GetEncoderValue() <= KSetPoint3)
		{
			CommandBase::pivot->MovePivotDOWN(KSetPoint2) ;
		}

		//At SetPoint4 or the UpperLimitSwitched is pressed we go to SetPoint3
		else if(CommandBase::pivot->GetEncoderValue() <= KSetPoint4 || CommandBase::pivot->GetUpperLimitSwitch() == true)
		{
			CommandBase::pivot->MovePivotDOWN(KSetPoint3) ;
		}
	}

	//If the remote is not touched in anyway then don't move the pivot at all
	else
	{
		CommandBase::pivot->StopPivot() ;
	}
}

// Make this return true when this Command no longer needs to run execute()
bool SearchAndMove::IsFinished()
{
	return false;
}

// Called once after isFinished returns true
void SearchAndMove::End()
{

}

// Called when another command which requires one or more of the same
// subsystems is scheduled to run
void SearchAndMove::Interrupted()
{

}




