#ifndef SearchAndMove_H
#define SearchAndMove_H

#include "../CommandBase.h"
#include "WPILib.h"

class SearchAndMove: public CommandBase
{
public:

	const float KDeadZoneLimit = .01 ;

	const float KSetPoint4 = 100 ;
	const float KSetPoint3 = 75 ;
	const float KSetPoint2 = 50 ;
	const float KSetPoint1 = 25 ;
	const float KSetPoint0 = 0 ;

	SearchAndMove();
	void Initialize();
	void Execute();
	bool IsFinished();
	void End();
	void Interrupted();
};

#endif
