#include "Collector.h"
#include "../RobotMap.h"
#include "Commands/MoveCollector.h"

Collector::Collector() :
		Subsystem("CollectorSubsystem")
{
	rightCollectorMotor = new CANTalon(11);

//	lw->AddActuator("Collector", "rightCollectorMotor", rightCollectorMotor);

	leftCollectorMotor = new CANTalon(9);
	rightCollectorMotor->SetFeedbackDevice(CANTalon::QuadEncoder);
//	lw->AddActuator("Collector", "leftCollectorMotor", leftCollectorMotor);

	//Slave the left motor to the right motor, and invert the right motor.
	rightCollectorMotor->SetControlMode(CANTalon::kFollower);	//Set the right motor as a slave
	rightCollectorMotor->Set(KCollectorMaster);					//to the left motor
	rightCollectorMotor->SetClosedLoopOutputDirection(true);	//invert the right motor relative to the master
	rightCollectorMotor->SetFeedbackDevice(CANTalon::QuadEncoder);
	rollerMotor = new CANTalon(10);
//	lw->AddActuator("Collector", "rollerMotor", rollerMotor);

//TODO verify the the collector and pivot limit switches are where we think they are
	collectorUpperLimit = new DigitalInput(0);
//	lw->AddSensor("Collector", "collectorArmUpSwitch", collectorArmUpSwitch);

	collectorLowerLimit = new DigitalInput(1);
//	lw->AddSensor("Collector", "collectorArmDownSwitch", collectorArmDownSwitch);
}

void Collector::InitDefaultCommand()
{
	// Set the default command for a subsystem here.
	SetDefaultCommand(new MoveCollector());
}

// Put methods for controlling this subsystem
// here. Call these from Commands.
//TODO need to determine encoder values for each of these positions


void Collector::CollectorCollectPosition()
{
	if (leftCollectorMotor->GetEncPosition() > KCollectorCollectPosition )
		{
			while(leftCollectorMotor->GetEncPosition() > KCollectorCollectPosition)
			{
				leftCollectorMotor->Set(-KCollectorSpeed);
			}
		}
		else if (leftCollectorMotor->GetEncPosition() < KCollectorCollectPosition )
		{
			while(leftCollectorMotor->GetEncPosition() < KCollectorCollectPosition)
			{
				leftCollectorMotor->Set(KCollectorSpeed);
			}
		}
}

void Collector::CollectorDrivePosition()
{
	if (leftCollectorMotor->GetEncPosition() > KCollectorDrivePosition )
	{
		while(leftCollectorMotor->GetEncPosition() > KCollectorDrivePosition)
		{
			leftCollectorMotor->Set(-KCollectorSpeed);
		}
	}
	else if (leftCollectorMotor->GetEncPosition() < KCollectorDrivePosition )
	{
		while(leftCollectorMotor->GetEncPosition() < KCollectorDrivePosition)
		{
			leftCollectorMotor->Set(KCollectorSpeed);
		}
	}
	StopCollector();
}
//Move the collector up until we hit the limit switch
void Collector::CollectorHighPosition()
{
	while(!IsAtUpperLimit())
	{
		leftCollectorMotor->Set(-KCollectorSpeed);
		SmartDashboard::PutNumber("Left Collector Encoder", (double)CollectorLeftEncoderPosition());
		SmartDashboard::PutNumber("Left Collector Encoder", (double)CollectorRightEncoderPosition());
	}
}

//Move the collector down until we hit the limit switch.
//TODO we need to initialize the encoders (and test their direction) so that
//when we start in the arms up position, the encoders reflect that
void Collector::CollectorRaiseBot()
{
	while(!IsAtLowerLimit())
	{
		leftCollectorMotor->Set(-KCollectorSpeed);
		SmartDashboard::PutNumber("Left Collector Encoder", (double)CollectorLeftEncoderPosition());
		SmartDashboard::PutNumber("Left Collector Encoder", (double)CollectorRightEncoderPosition());
	}
	if (IsAtLowerLimit())
	{
		leftCollectorMotor->SetEncPosition(0);	// reset the encoders
		rightCollectorMotor->SetEncPosition(0);
	}
}
bool Collector::IsAtUpperLimit()
{
	return collectorUpperLimit->Get();
}

bool Collector::IsAtLowerLimit()
{
	return collectorLowerLimit->Get();
}

int Collector::CollectorLeftEncoderPosition()
{
	return (leftCollectorMotor->GetEncPosition());
}

int Collector::CollectorRightEncoderPosition()
{
	return (rightCollectorMotor->GetEncPosition());
}

void Collector::StopCollector()
{
	leftCollectorMotor->Set(0);
}
