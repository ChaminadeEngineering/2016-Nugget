#include "Shooter.h"
#include "../RobotMap.h"

Shooter::Shooter() :
		Subsystem("ExampleSubsystem")
{

	rightFlywheelMotor = new CANTalon(7);
//	lw->AddActuator("Shooter", "rightFlywheelMotor", shooterrightFlywheelMotor);

	leftFlywheelMotor = new CANTalon(8);
//	lw->AddActuator("Shooter", "leftFlywheelMotor", shooterleftFlywheelMotor);

	shooterSolenoid = new DoubleSolenoid(2, 3, 1);
//	lw->AddActuator("Shooter", "kickerSolenoid", shooterkickerSolenoid);
}

void Shooter::InitDefaultCommand()
{
	// Set the default command for a subsystem here.
	//SetDefaultCommand(new MySpecialCommand());
}

// Put methods for controlling this subsystem
// here. Call these from Commands.
void Shooter::PanicKick()
{
	shooterSolenoid->Set(DoubleSolenoid::kForward);
	Wait(0.5);
	shooterSolenoid->Set(DoubleSolenoid::kReverse);
	Wait(0.5);
	shooterSolenoid->Set(DoubleSolenoid::kOff);
}
