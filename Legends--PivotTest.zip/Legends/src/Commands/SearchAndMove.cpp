/*
 * SearchAndMove.cpp
 *
 *  Created on: Mar 3, 2016
 *      Author: eeuser
 */
#include "SearchAndMove.h"


SearchAndMove::SearchAndMove()
{
	// Use Requires() here to declare subsystem dependencies
	// eg. Requires(chassis);
	Requires(CommandBase::pivot);
}


void SearchAndMove::Initialize()
{

}

//Called repeatedly when this Command is scheduled to run

void SearchAndMove::Execute()
{
	if(CommandBase::oi->getLeftXBoxAxis() > KDeadZoneLimit)
	{
		CommandBase::pivot->MovePivotUP() ;
	}
	else if(CommandBase::oi->getLeftXBoxAxis() < -KDeadZoneLimit)
	{
		CommandBase::pivot->MovePivotDOWN() ;
	}
	else if(CommandBase::pivot->GetUpperLimitSwitch() == true || CommandBase::pivot->GetLowerLimitSwitch() == true)
	{
		CommandBase::pivot->StopPivot() ;
	}
}

// Make this return true when this Command no longer needs to run execute()
bool SearchAndMove::IsFinished()
{
	return false;
}

// Called once after isFinished returns true
void SearchAndMove::End()
{

}

// Called when another command which requires one or more of the same
// subsystems is scheduled to run
void SearchAndMove::Interrupted()
{

}




