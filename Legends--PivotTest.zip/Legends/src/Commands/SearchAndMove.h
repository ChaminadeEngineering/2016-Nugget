#ifndef SearchAndMove_H
#define SearchAndMove_H

#include "../CommandBase.h"
#include "WPILib.h"

class SearchAndMove: public CommandBase
{
public:

	const float KDeadZoneLimit = .01 ;

	SearchAndMove();
	void Initialize();
	void Execute();
	bool IsFinished();
	void End();
	void Interrupted();
};

#endif
