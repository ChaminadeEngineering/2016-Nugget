#include "Pivot.h"
#include "../RobotMap.h"

Pivot::Pivot() :
		Subsystem("PivotSubsystem")
{
	pivotMotor = new CANTalon(12);
//	lw->AddActuator("Pivot", "pivotMotor", pivotMotor);


	pivotLowerLimit = new DigitalInput(2);
//	lw->AddSensor("Pivot", "PivotLowerLimit", pivotLowerLimit);

	pivotEncoder = new Encoder(3, 4, false, Encoder::k4X);
//	lw->AddSensor("Pivot", "PivotEncoder", pivotEncoder);

	pivotEncoder->SetDistancePerPulse(1.0);

	pivotEncoder->SetPIDSourceType(PIDSourceType::kRate);

	pivotUpperLimit = new DigitalInput(5);
//	lw->AddSensor("Pivot", "PivotUpperLimit", pivotUpperLimit);


}

void Pivot::InitDefaultCommand()
{
	// Set the default command for a subsystem here.
	Pivot::pivotMotor->SetInverted(true);
}

// Put methods for controlling this subsystem
// here. Call these from Commands.


/*******************************************
 * GETS THE ENCODER VALUE!!!
 *******************************************/
int Pivot::GetEncoderValue()
{
	return pivotEncoder->Get() ;
} //end of GetEncoderValue


/*******************************************
 * MOVES THE PIVOT MOTOR IN THE UP POSTION!!!
 *******************************************/
void Pivot::MovePivotUP()
{
	float speed = KPivotSpeed ;

		pivotMotor->Set(speed) ;

} //end of MovePivotUP


/*******************************************
 * MOVES THE PIVOT MOTOR IN THE DOWN POSTION!!!
 *******************************************/
void Pivot::MovePivotDOWN()
{
	float speed = KPivotSpeed ;

		pivotMotor->Set(speed) ;

} //end of MovePivotDOWN


/*******************************************
 * STOPS THE PIVOT MOTOR!!!
 *******************************************/
void Pivot::StopPivot()
{
	pivotMotor->Set(0);
}//End of StopPivot()

int Pivot::GetUpperLimitSwitch()
{
	return pivotUpperLimit->Get() ;
}

int Pivot::GetLowerLimitSwitch()
{
	return pivotLowerLimit->Get() ;
}
