#ifndef Pivot_H
#define Pivot_H

#include "Commands/Subsystem.h"
#include "WPILib.h"

class Pivot: public Subsystem
{
private:
	CANTalon* pivotMotor ;
	DigitalInput* pivotLowerLimit ;
	Encoder* pivotEncoder ;
	DigitalInput* pivotUpperLimit ;

	const float KDeadZoneLimit = .01 ;

	const float KPivotSpeed = .33 ;

public:

	Pivot();
	void InitDefaultCommand() ;
	void SearchAndMove(float controller) ;
	int GetEncoderValue() ;
	void MovePivotUP() ;
	void MovePivotDOWN() ;
	void StopPivot() ;
	int GetUpperLimitSwitch() ;
	int GetLowerLimitSwitch() ;


};

#endif
