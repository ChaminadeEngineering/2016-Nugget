#ifndef DrivePosition_H
#define DrivePosition_H

#include "Commands/CommandGroup.h"
#include "WPILib.h"

class DrivePosition: public CommandGroup
{
public:
	DrivePosition();
};

#endif
