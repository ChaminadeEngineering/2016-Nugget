#ifndef CollectorHighPosition_H
#define CollectorHighPosition_H

#include "../CommandBase.h"
#include "WPILib.h"

class CollectorHighPosition: public CommandBase
{
public:
	CollectorHighPosition();
	void Initialize();
	void Execute();
	bool IsFinished();
	void End();
	void Interrupted();
};

#endif
