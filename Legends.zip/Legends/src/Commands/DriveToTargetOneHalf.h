#ifndef DriveToTargetOneHalf_H
#define DriveToTargetOneHalf_H

#include "../CommandBase.h"
#include "WPILib.h"

class DriveToTargetOneHalf: public CommandBase
{
public:
	DriveToTargetOneHalf();
	void Initialize();
	void Execute();
	bool IsFinished();
	void End();
	void Interrupted();
	const float KBaseAutonSpeed = 0.3;	//Drive Slowly
	const float KBDAutonSpeed = 0.5;
	const float KLowBarDistance = 100; //Inches
};

#endif
