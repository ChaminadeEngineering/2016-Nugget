#ifndef SpitBall_H
#define SpitBall_H

#include "../CommandBase.h"
#include "WPILib.h"

class SpitBall: public CommandBase
{
public:
	SpitBall();
	void Initialize();
	void Execute();
	bool IsFinished();
	void End();
	void Interrupted();
};

#endif
