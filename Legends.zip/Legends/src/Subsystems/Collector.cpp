#include "Collector.h"
#include "../RobotMap.h"
#include "Commands/MoveCollector.h"
#include "Commands/CollectorWithJoystick.h"

Collector::Collector() :
		Subsystem("CollectorSubsystem")
{
	rightCollectorMotor = new CANTalon(11);

//	lw->AddActuator("Collector", "rightCollectorMotor", rightCollectorMotor);

	leftCollectorMotor = new CANTalon(9);
	leftCollectorMotor->SetFeedbackDevice(CANTalon::QuadEncoder);
//	lw->AddActuator("Collector", "leftCollectorMotor", leftCollectorMotor);

	//Slave the left motor to the right motor, and invert the right motor.
	rightCollectorMotor->SetControlMode(CANTalon::kFollower);	//Set the right motor as a slave
	rightCollectorMotor->Set(KCollectorMaster);					//to the left motor
	rightCollectorMotor->SetClosedLoopOutputDirection(true);	//invert the right motor relative to the master

	rightCollectorMotor->SetFeedbackDevice(CANTalon::QuadEncoder);

//INFO Collector upper limit switch - DIO 5
	collectorUpperLimit = new DigitalInput(5);
//INFO Right collector arm upper limit switch - DIO 6
	rightCollectorUpperLimit = new DigitalInput(6);
//	lw->AddSensor("Collector", "collectorArmUpSwitch", collectorArmUpSwitch);
	rightCollectorLowerLimit = new DigitalInput(7) ;
//INFO Collector lower limit switch - DIO 2
	collectorLowerLimit = new DigitalInput(2);

//	lw->AddSensor("Collector", "collectorArmDownSwitch", collectorArmDownSwitch);
}

void Collector::InitDefaultCommand()
{
	// Set the default command for a subsystem here.
	//SetDefaultCommand(new MoveCollector());
	SetDefaultCommand(new CollectorWithJoystick() );
}

// Put methods for controlling this subsystem
// here. Call these from Commands.
//TODO need to determine encoder values for each of these positions

//This routine is for testing the collector.  It will move the collector up or down
//based on the right XBox controller until it reaches the limit switch.
//We need to use this to get the encoder values for the various positions we want.
//TODO can we light up an indicator when the robot is in a particular range?

void Collector::CollectorRunToLimitSwitch(float direction)
{
	SmartDashboard::PutNumber("Left Collector Encoder", (double)CollectorLeftEncoderPosition());
	SmartDashboard::PutNumber("Left Collector Encoder", (double)CollectorRightEncoderPosition());
//	SmartDashboard::PutBoolean("Upper Limit", CollectorIsAtUpperLimit());
//	SmartDashboard::PutBoolean("Lower Limit", CollectorIsAtLowerLimit());

	//Moving up
	if (direction >= KDeadZoneLimit && CollectorIsAtUpperLimit() == false)//moving up
	{
		leftCollectorMotor->Set(KCollectorSpeed);
		//rightCollectorMotor->Set(-KCollectorSpeed);

	}
	//Moving down

	else if (direction <= -KDeadZoneLimit && CollectorIsAtLowerLimit() == false)//moving down
//	else if(direction<=-KDeadZoneLimit)
	{
		leftCollectorMotor->Set(-KCollectorSpeed);
		//rightCollectorMotor->Set(KCollectorSpeed);

	}
	else
	{
		StopCollector();

	}
	//if the left is at the upper limit, and the right arm is not, slowly move
	//the right arm up to match the left, then set encoders to 0
	if(CollectorIsAtLowerLimit())
	{
		leftCollectorMotor->SetEncPosition(0);

//		while(!RightCollectorIsAtLowerLimit())
//		{
//			rightCollectorMotor->Set(KCollectorSpeed/2);//move down slowly
//		}
		//rightCollectorMotor->Set(0);

		//rightCollectorMotor->SetEncPosition(0);

	}
	if(CollectorIsAtUpperLimit())
	{

//		while (!RightCollectorIsAtUpperLimit())
//		{
//			rightCollectorMotor->Set(-KCollectorSpeed/2);//move up slowly
//		}
//		rightCollectorMotor->Set(0);

	}

//	if(CollectorIsAtUpperLimit())
//		{
//
//			while (!RightCollectorIsAtUpperLimit())
//			{
//				rightCollectorMotor->Set(-KCollectorSpeed/2);//move up slowly
//			}
//			rightCollectorMotor->Set(0);
//
//		}

}
//need to check the sense of the collector encoder
void Collector::CollectorToCollectPosition()
{
	if (leftCollectorMotor->GetEncPosition() > KCollectorCollectPosition )
	{
		//Moving down
		while(leftCollectorMotor->GetEncPosition() > KCollectorCollectPosition)
		{
			leftCollectorMotor->Set(-KCollectorSpeed);
			//rightCollectorMotor->Set(KCollectorSpeed);
		}
	}

	else if (leftCollectorMotor->GetEncPosition() < KCollectorCollectPosition )
	{
		//moving up
		while(leftCollectorMotor->GetEncPosition() < KCollectorCollectPosition)
		{
			leftCollectorMotor->Set(KCollectorSpeed);
			//rightCollectorMotor->Set(-KCollectorSpeed);
		}
	}
	StopCollector();
}

void Collector::CollectorToDrivePosition()
{


	/*if (leftCollectorMotor->GetEncPosition() > KCollectorCollectPosition )
	{
		//Moving down
		while(leftCollectorMotor->GetEncPosition() > KCollectorCollectPosition)
		{
			leftCollectorMotor->Set(-KCollectorSpeed);
			rightCollectorMotor->Set(KCollectorSpeed);
		}
	}

	else if (leftCollectorMotor->GetEncPosition() < KCollectorCollectPosition )
	{
		//moving up
		while(leftCollectorMotor->GetEncPosition() < KCollectorCollectPosition)
		{
			leftCollectorMotor->Set(KCollectorSpeed);
			rightCollectorMotor->Set(-KCollectorSpeed);
		}
	}

	StopCollector();*/


	while (CollectorIsAtLowerLimit() == false)//moving down
	{
		leftCollectorMotor->Set(-KCollectorSpeed);
		//rightCollectorMotor->Set(KCollectorSpeed);
	}
	StopCollector();

		//if the left is at the upper limit, and the right arm is not, slowly move
		//the right arm up to match the left, then set encoders to 0
//		if(CollectorIsAtUpperLimit())
//		{
//			//leftCollectorMotor->SetEncPosition(0);
////			while (!RightCollectorIsAtLowerLimit())
////			{
////				rightCollectorMotor->Set(KCollectorSpeed/2);//move down at half speed
////			}
////			rightCollectorMotor->Set(0);
//		}
	StopCollector();

	leftCollectorMotor->SetEncPosition(0);
	//rightCollectorMotor->SetEncPosition(0);
}
//Move the collector up until we hit the limit switch
void Collector::CollectorToHighPosition()
{
	while(!CollectorIsAtUpperLimit())
	{
		leftCollectorMotor->Set(-KCollectorSpeed);
		SmartDashboard::PutNumber("Left Collector Encoder", (double)CollectorLeftEncoderPosition());
		SmartDashboard::PutNumber("Left Collector Encoder", (double)CollectorRightEncoderPosition());
	}
}

//Move the collector down until we hit the limit switch.
//TODO we need to initialize the encoders (and test their direction) so that
//when we start in the arms up position, the encoders reflect that
void Collector::CollectorRaiseBot()
{
	while(!CollectorIsAtLowerLimit())
	{
		leftCollectorMotor->Set(-KCollectorSpeed);
	}
	if (CollectorIsAtLowerLimit())
	{
		leftCollectorMotor->SetEncPosition(0);	// reset the encoders
		//rightCollectorMotor->SetEncPosition(0);
	}
}

bool Collector::CollectorIsAtUpperLimit()
{
	return collectorUpperLimit->Get();
}

bool Collector::RightCollectorIsAtUpperLimit()
{
	return rightCollectorUpperLimit->Get();
}

bool Collector::CollectorIsAtLowerLimit()
{
	return collectorLowerLimit->Get();
}

int Collector::CollectorLeftEncoderPosition()
{
	return (leftCollectorMotor->GetEncPosition());
}

int Collector::CollectorRightEncoderPosition()
{
	return (rightCollectorMotor->GetEncPosition());
}

void Collector::StopCollector()
{
	leftCollectorMotor->Set(0);
	//rightCollectorMotor->Set(0) ;
}

bool Collector::RightCollectorIsAtLowerLimit()
{
	return rightCollectorLowerLimit->Get();
}

