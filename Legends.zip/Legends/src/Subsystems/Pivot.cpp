#include "Pivot.h"
#include "../RobotMap.h"

Pivot::Pivot() :
		Subsystem("PivotSubsystem")
{
	pivotMotor = new CANTalon(9);
//	lw->AddActuator("Pivot", "pivotMotor", pivotMotor);


	pivotLowerLimit = new DigitalInput(2);
//	lw->AddSensor("Pivot", "PivotLowerLimit", pivotLowerLimit);

	pivotEncoder = new Encoder(3, 4, false, Encoder::k4X);
//	lw->AddSensor("Pivot", "PivotEncoder", pivotEncoder);

	pivotEncoder->SetDistancePerPulse(1.0);

	pivotEncoder->SetPIDSourceType(PIDSourceType::kRate);

	pivotUpperLimit = new DigitalInput(5);
//	lw->AddSensor("Pivot", "PivotUpperLimit", pivotUpperLimit);
}

void Pivot::InitDefaultCommand()
{
	// Set the default command for a subsystem here.
	Pivot::pivotMotor->SetInverted(true);
}

// Put methods for controlling this subsystem
// here. Call these from Commands.
