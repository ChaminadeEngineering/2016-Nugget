#ifndef Pivot_H
#define Pivot_H

#include "Commands/Subsystem.h"
#include "WPILib.h"

class Pivot: public Subsystem
{
private:
	CANTalon* pivotMotor;
	DigitalInput* pivotLowerLimit;
	Encoder* pivotEncoder;
	DigitalInput* pivotUpperLimit;

public:
	Pivot();
	void InitDefaultCommand();
};

#endif
