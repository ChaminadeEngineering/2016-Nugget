#include "Vision.h"
#include "../RobotMap.h"

Vision::Vision() :
		Subsystem("VisionSubsystem")
{

	CameraServer::GetInstance()->SetQuality(50);
	CameraServer::GetInstance()->StartAutomaticCapture("cam0");
}

void Vision::InitDefaultCommand()
{
	// Set the default command for a subsystem here.
	//SetDefaultCommand(new MySpecialCommand());

	//SetDefaultCommand(new VisionUpdate) ;
}




