#include "BDObstacle.h"
#include "Commands/ShiftBaseDown.h"
//#include "Commands/DriveToTarget.h"
#include "Commands/DriveToTargetOneHalf.h"

BDObstacle::BDObstacle()
{
	Requires(CommandBase::driveTrain);
		//Requires(CommandBase::collector);
		//Raise the collector all the way up so we reset the encoders
		//Shift the base into low gear
		//Move the collector arms to the drie position
		//Drive forward under the low bar
		//AddSequential(new CollectorHighPosition());
		AddSequential(new ShiftBaseDown());
		//AddSequential(new CollectorDrivePosition());
		AddSequential(new DriveToTargetOneHalf());
}
