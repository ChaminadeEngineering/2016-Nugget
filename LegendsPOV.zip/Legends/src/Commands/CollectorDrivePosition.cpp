#include "CollectorDrivePosition.h"

CollectorDrivePosition::CollectorDrivePosition()
{
	// Use Requires() here to declare subsystem dependencies
	// eg. Requires(chassis);
	Requires(CommandBase::collector);
}

// Called just before this Command runs the first time
void CollectorDrivePosition::Initialize()
{

}

// Called repeatedly when this Command is scheduled to run
void CollectorDrivePosition::Execute()
{
	collector->CollectorToDrivePosition();
}

// Make this return true when this Command no longer needs to run execute()
bool CollectorDrivePosition::IsFinished()
{
	return true;
}

// Called once after isFinished returns true
void CollectorDrivePosition::End()
{

}

// Called when another command which requires one or more of the same
// subsystems is scheduled to run
void CollectorDrivePosition::Interrupted()
{

}
