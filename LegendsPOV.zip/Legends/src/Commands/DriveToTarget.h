#ifndef DriveToTarget_H
#define DriveToTarget_H

#include "../CommandBase.h"
#include "WPILib.h"

class DriveToTarget: public CommandBase
{
public:
	DriveToTarget();
	void Initialize();
	void Execute();
	bool IsFinished();
	void End();
	void Interrupted();
	const float KBaseAutonSpeed = 0.3;	//Drive Slowly
	const float KBDAutonSpeed = 0.5;
	const float KLowBarDistance = 100; //Inches
};

#endif
