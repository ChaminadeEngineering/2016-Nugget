#ifndef HighGoalKick_H
#define HighGoalKick_H

#include "../CommandBase.h"
#include "Commands/CommandGroup.h"
#include "WPILib.h"

class HighGoalKick: public CommandGroup
{
public:
	HighGoalKick();
};

#endif
