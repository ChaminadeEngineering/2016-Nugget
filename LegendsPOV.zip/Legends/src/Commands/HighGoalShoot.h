#ifndef HighGoalShoot_H
#define HighGoalShoot_H

#include "../CommandBase.h"
#include "Commands/CommandGroup.h"
#include "WPILib.h"

class HighGoalShoot: public CommandGroup
{
public:
	HighGoalShoot();
};

#endif
