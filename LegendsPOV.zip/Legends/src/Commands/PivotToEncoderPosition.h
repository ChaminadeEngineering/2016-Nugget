#ifndef PivotToEncoderPosition_H
#define PivotToEncoderPosition_H

#include "../CommandBase.h"
#include "WPILib.h"

class PivotToEncoderPosition: public CommandBase
{
public:
	PivotToEncoderPosition();
	void Initialize();
	void Execute();
	bool IsFinished();
	void End();
	void Interrupted();
};

#endif
