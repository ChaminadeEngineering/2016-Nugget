
#include "PivotWithJoystick.h"

PivotWithJoystick::PivotWithJoystick()
{
	// Use Requires() here to declare subsystem dependencies
	// eg. Requires(chassis);
	Requires(CommandBase::pivot);
}

// Called just before this Command runs the first time
void PivotWithJoystick::Initialize()
{

}

// Called repeatedly when this Command is scheduled to run
void PivotWithJoystick::Execute()
{
	int povvalue = oi->getXBoxPOV();
	float triggerleft = oi->getLeftXBoxTrigger();
	float triggerright = oi->getRightXBoxTrigger();

	SmartDashboard::PutNumber("Pov value",(double)oi->getXBoxPOV() );
	if (povvalue > -1)
	{
		switch(povvalue)
		{
		case 90:					//90 is the right position, and is undefined
			break;
		case 0:						//0 is the up position
			pivot->PivotToShootPosition1();
			break;
		case 180:					//180 is the down position
			pivot->PivotToShootPosition2();
			break;
		case 270:					//270 is the left position
			pivot->PivotToDrivePosition();
			break;
		}
	}
	else
	{
		if (triggerleft > KDeadZoneLimit)		//move up on left trigger
		{
			CommandBase::pivot->PivotRunSlowly(1);
		}
		else if (triggerright > KDeadZoneLimit)	//move down on right trigger
		{
			CommandBase::pivot->PivotRunSlowly(-1);
		}
		else
			CommandBase::pivot->PivotRunToLimit(oi->getLeftXBoxAxis());
	}
}

// Make this return true when this Command no longer needs to run execute()
bool PivotWithJoystick::IsFinished()
{
	return false;
}

// Called once after isFinished returns true
void PivotWithJoystick::End()
{

}

// Called when another command which requires one or more of the same
// subsystems is scheduled to run
void PivotWithJoystick::Interrupted()
{

}
