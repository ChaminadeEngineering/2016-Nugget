#ifndef ReverseBase_H
#define ReverseBase_H

#include "../CommandBase.h"
#include "RobotMap.h"
#include "WPILib.h"

class ReverseBase: public CommandBase
{
public:
	ReverseBase();
	void Initialize();
	void Execute();
	bool IsFinished();
	void End();
	void Interrupted();
};

#endif
