#ifndef ShiftBaseDown_H
#define ShiftBaseDown_H

#include "../CommandBase.h"
#include "WPILib.h"

class ShiftBaseDown: public CommandBase
{
public:
	ShiftBaseDown();
	void Initialize();
	void Execute();
	bool IsFinished();
	void End();
	void Interrupted();
};

#endif
