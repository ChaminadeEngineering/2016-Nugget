#ifndef Pivot_H
#define Pivot_H

#include "Commands/Subsystem.h"
#include "WPILib.h"

class Pivot: public Subsystem
{
private:
	CANTalon* pivotMotor;
	DigitalInput* pivotLowerLimit;
	DigitalInput* pivotUpperLimit;

public:
	Pivot();
	void InitDefaultCommand();
	void PivotRunToLimit(float direction);
	bool PivotIsAtLowerLimit();
	bool PivotIsAtUpperLimit();
	int PivotEncoderPosition();
	void StopPivot();
	void PivotMoveToEncoderPosition();
	void PivotToDrivePosition();
	void PivotToShootPosition1();
	void PivotToShootPosition2();
	void PivotRunSlowly(float direction);

	const float KPivotSlowSpeed = 0.5;
	const int KPivotDrivePosition = 235000;
	const int KPivotShootPosition1 = 110500; 	//Forward shoot position
	const int KPivotShootPosition2 = 15000;		//rear shoot position
	const int KEncoderErrorLimit = 500;			//we aren't going to try to get right on

};

#endif
