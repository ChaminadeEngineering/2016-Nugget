#ifndef OperateCollector_H
#define OperateCollector_H

//#include "../CommandBase.h"
#include "WPILib.h"

class OperateCollector: public Command
{
public:
	OperateCollector();
	void Initialize();
	void Execute();
	bool IsFinished();
	void End();
	void Interrupted();
};

#endif
