#include "RotateShooter.h"

RotateShooter::RotateShooter(): Command() {

        // Use requires() here to declare subsystem dependencies
    // eg. requires(chassis);

	Requires(Robot::pivot.get());
}


// Called just before this Command runs the first time
void RotateShooter::Initialize()
{

}

// Called repeatedly when this Command is scheduled to run
void RotateShooter::Execute()
{
	// Pass the joystick value for the pivot motor.  Move the pivot motor towards the next target if its not at a limit, and we aren't in the deadzone,
	Robot::pivot->SearchAndMove(Robot::oi->getLeftXBoxAxis());
}

// Make this return true when this Command no longer needs to run execute()
bool RotateShooter::IsFinished()
{
	return false;
}

// Called once after isFinished returns true
void RotateShooter::End()
{

}

// Called when another command which requires one or more of the same
// subsystems is scheduled to run
void RotateShooter::Interrupted()
{

}
