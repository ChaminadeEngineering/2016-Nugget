#ifndef RotateShooter_H
#define RotateShooter_H

#include "Commands/Subsystem.h"
#include "../Robot.h"
/**
 *
 *
 * @author ExampleAuthor
 */
class RotateShooter: public Command
{
public:

	RotateShooter();
	void Initialize();
	void Execute();
	bool IsFinished();
	void End();
	void Interrupted();
};

#endif
