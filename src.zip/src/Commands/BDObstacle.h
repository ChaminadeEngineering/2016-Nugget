#ifndef BDObstacle_H
#define BDObstacle_H

#include "Commands/CommandGroup.h"
#include "WPILib.h"

class BDObstacle: public CommandGroup
{
public:
	BDObstacle();
};

#endif
