#ifndef CollectorDrivePosition_H
#define CollectorDrivePosition_H

#include "../CommandBase.h"
#include "WPILib.h"

class CollectorDrivePosition: public CommandBase
{
public:
	CollectorDrivePosition();
	void Initialize();
	void Execute();
	bool IsFinished();
	void End();
	void Interrupted();
};

#endif
