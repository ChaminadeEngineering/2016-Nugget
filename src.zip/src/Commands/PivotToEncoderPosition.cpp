#include "PivotToEncoderPosition.h"

PivotToEncoderPosition::PivotToEncoderPosition()
{
	// Use Requires() here to declare subsystem dependencies
	// eg. Requires(chassis);
	Requires(pivot);
}

// Called just before this Command runs the first time
void PivotToEncoderPosition::Initialize()
{

}

// Called repeatedly when this Command is scheduled to run
void PivotToEncoderPosition::Execute()
{
	if(CommandBase::oi->getXBoxPOV() == 90)
	{
		CommandBase::pivot->PivotMoveToEncoderPosition() ;
	}
}

// Make this return true when this Command no longer needs to run execute()
bool PivotToEncoderPosition::IsFinished()
{
	return true;
}

// Called once after isFinished returns true
void PivotToEncoderPosition::End()
{

}

// Called when another command which requires one or more of the same
// subsystems is scheduled to run
void PivotToEncoderPosition::Interrupted()
{

}
